import { GeoLocation } from './GeoLocation.model';

export class Address {
  constructor(public street: string, public housenumber: string, public postalcode: string, public geoLocation: GeoLocation) {}
}
