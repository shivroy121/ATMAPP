export class GeoLocation {
  constructor(public lat: number, public lng: number) {}
}
