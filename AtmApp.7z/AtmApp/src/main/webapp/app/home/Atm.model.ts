export class AtmResponse {
  constructor(public address: Address, public distance: number, public type: string) {}
}

export class Address {
  constructor(public street: string,public city: string, public housenumber: number, public postalcode: number , public geoLocation: GeoLocation) {}
}

export class GeoLocation {
  constructor(public lat: number, public lng: number) {}
}
