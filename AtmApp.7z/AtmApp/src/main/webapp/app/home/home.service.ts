import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { ATM_SERVER_API_URL } from '../app.constants';
import { AtmResponse } from '../home/Atm.model';

@Injectable({ providedIn: 'root' })
export class AtmService {
  
 constructor(private http: HttpClient) {}

 findAllAtm():  Observable<{}> {
    return this.http.get<AtmResponse>(ATM_SERVER_API_URL);
  }
}
