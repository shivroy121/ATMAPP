/* after changing this file run 'npm run webpack:build' */
import '../content/scss/vendor.scss';
