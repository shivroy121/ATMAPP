package com.hexaware.atm.dto;

import java.util.List;

public class Atm {
	
	private Address address;
	
	private long distance;
	
	private List<String> functionality;
	
	private String type;

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public long getDistance() {
		return distance;
	}

	public void setDistance(long distance) {
		this.distance = distance;
	}

	public List<String> getFunctionality() {
		return functionality;
	}

	public void setFunctionality(List<String> functionality) {
		this.functionality = functionality;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	

}
