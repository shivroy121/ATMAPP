/**
 * Service layer beans.
 */
package com.hexaware.atm.service;
