/**
 * View Models used by Spring MVC REST controllers.
 */
package com.hexaware.atm.web.rest.vm;
