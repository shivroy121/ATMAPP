/**
 * Spring Security configuration.
 */
package com.hexaware.atm.security;
