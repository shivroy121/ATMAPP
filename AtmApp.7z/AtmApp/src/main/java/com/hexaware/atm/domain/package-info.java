/**
 * JPA domain objects.
 */
package com.hexaware.atm.domain;
