package com.hexaware.atm.web.rest;

import java.lang.reflect.Type;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hexaware.atm.dto.Atm;

@RestController
@RequestMapping("/api/atm")
public class AtmResource {

	private final String uri = "https://www.ing.nl/api/locator/atms/";

	@Autowired
	private RestTemplate restTemplate;

	@GetMapping
	public List<Atm> getAtmAccount() {

		String jsonString = restTemplate.getForObject(uri, String.class);
		jsonString = jsonString.replace(")]}',", "").trim();
		Gson gson = new Gson();
		Type type = new TypeToken<List<Atm>>() {
		}.getType();
		List<Atm> atms = gson.fromJson(jsonString, type);
		
		return atms;

	}

}
