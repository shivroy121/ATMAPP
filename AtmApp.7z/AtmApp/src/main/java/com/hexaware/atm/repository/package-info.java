/**
 * Spring Data JPA repositories.
 */
package com.hexaware.atm.repository;
